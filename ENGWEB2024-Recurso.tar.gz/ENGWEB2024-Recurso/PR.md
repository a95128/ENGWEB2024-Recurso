O dataset foi alterado manualmente recorrendo a ctrl+f e replace all do id para `_id` , de seguida recorreu-se ao script `script.py` para converter as listas que eram strings, para listas

Para o setup da base de dados utilizei os seguintes comandos:


    $ sudo docker pull mongo
    $ sudo docker run -d -p 27017:27017 --name [NomeADefinir] mongo
    $ sudo docker cp plantas.json [NomeADefinir]:/tmp
    $ sudo docker exec -it [NomeADefinir] bash
    $ ls /tmp

    $ mongosh

sendo o nomeAdefinir = exame2024

Quanto às respostas textuais estas estão incluídas o código e a resposta em `queries.txt`.

Para executar as aplicações envolvidas basta correr o comando `npm i` e npm `start` na diretoria da API (/ex1) e o mesmo na diretoria da interface (/ex2). Caso haja algum erro, pode ser necessário fazer `npm i mongoose` para a API e `npm i axios` para a interface.