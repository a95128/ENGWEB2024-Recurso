var express = require('express');
var router = express.Router();
var axios = require('axios');

/* GET home page. */
router.get('/', function(req, res) {
  var d = new Date().toISOString().substring(0,16)
  axios.get('http://localhost:17000/books')
                    .then(resposta => {
                      res.render('index', { books: resposta.data, data: d});
                    })
                    .catch( erro => {
                      res.render('error', {error: erro, message: 'Erro ao recuperar os livros'})
                    })
});

router.get('/:id', function(req, res) {
  var d = new Date().toISOString().substring(0,16)
  axios.get('http://localhost:17000/books/'+ req.params.id)
                    .then(resposta => {
                      res.render('livro', { livro: resposta.data, data: d});
                    })
                    .catch( erro => {
                      res.render('error', {error: erro, message: 'Erro ao recuperar o livro'})
                    })
});

function contarLivrosPorAutor(livros, autor) {
  const livrosFiltrados = livros.filter(livro => livro.author.includes(autor));

  return livrosFiltrados.length;
}


router.get('/authors/:idAutor', function(req, res) {
  var d = new Date().toISOString().substring(0,16)
  axios.get('http://localhost:17000/books?author='+ req.params.idAutor)
                    .then(resposta => {
                      var somatorio = contarLivrosPorAutor(resposta.data);
                      res.render('author', { books: resposta.data, data: d,somatorio, nome: resposta.data[0].author,
                        idAutor: resposta.data[0].author});

                    })
                    .catch( erro => {
                      res.render('error', {error: erro, message: 'Erro ao recuperar o livro'})
                    })
});


module.exports = router;