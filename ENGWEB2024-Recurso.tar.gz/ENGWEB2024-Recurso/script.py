import json

def process_book_data(book):
    book['_id'] = book.pop('bookId')
    
    

    book['genres'] = eval(book['genres']) if isinstance(book['genres'], str) else book['genres']
    book['characters'] = eval(book['characters']) if isinstance(book['characters'], str) else book['characters']
    book['awards'] = eval(book['awards']) if isinstance(book['awards'], str) else book['awards']
    book['setting'] = eval(book['setting']) if isinstance(book['setting'], str) else book['setting']
    book['author'] = [author.strip() for author in book['author'].split(',')]
    book['ratingsByStars'] = eval(book['ratingsByStars']) if isinstance(book['ratingsByStars'], str) else book['setting']

    
    return book

def process_dataset(input_file, output_file):
    with open(input_file, 'r') as infile:
        data = json.load(infile)
    
    processed_data = [process_book_data(book) for book in data]
    
    with open(output_file, 'w') as outfile:
        json.dump(processed_data, outfile, indent=4)

input_file = 'dataset.json'
output_file = 'processed_books.json'

process_dataset(input_file, output_file)
